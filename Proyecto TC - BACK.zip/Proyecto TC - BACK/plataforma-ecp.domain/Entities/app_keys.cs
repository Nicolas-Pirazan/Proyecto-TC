﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace plataforma_ecp.domain.Entities
{

    public class keysList
    {
        public  string ?nombre { get; set; }
        public  string ?valor { get; set; }
    }



}
