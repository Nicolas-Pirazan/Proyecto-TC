 
create table usuarios_sedes(
id_usuario int NOT NULL, id_sede smallint NOT NULL, estado bit default 1)