 
create table medios(
id tinyint not null,
medio varchar(20)
)
go

insert into medios(id, medio) values(1,'Un conocido')
insert into medios(id, medio) values(2,'Internet')
insert into medios(id, medio) values(3,'Publicidad')
insert into medios(id, medio) values(4,'Vi la escuela')

