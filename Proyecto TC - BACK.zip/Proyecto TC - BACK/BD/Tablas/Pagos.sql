 
create table pagos(
run varchar(15) not null,
paymentId varchar(200) ,
preferenceId varchar(200) ,
status varchar(20) ,
fecha_creacion datetime,
fecha_modificacion datetime
)